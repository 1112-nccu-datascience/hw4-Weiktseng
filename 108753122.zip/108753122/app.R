library(shiny)
library(ggplot2)
library(ggbiplot)
library(FactoMineR)
library(factoextra)
#runExample("01_hello")

ui <- fluidPage(
  navbarPage("曾偉綱108753122",
    tabPanel("iris data",
      tabsetPanel(
        tabPanel("Plot",
          fluidRow(
            column(3,
              checkboxGroupInput("iris_variables", "Chose 2 column:",
                 choices = colnames(iris[, 1:4]),
                 selected = c("Sepal.Length", "Sepal.Width"))),
            column(9,plotOutput("irisPlot") ) )
                        ),
                        tabPanel("Summary", verbatimTextOutput("irisSummary")), 
                        tabPanel("Data", tableOutput("irisTable"))
                      )       
             ),
    tabPanel("PCA",tabsetPanel(
     tabPanel("Plot",sidebarLayout(sidebarPanel(checkboxGroupInput("PCs", "Chose 2 column:", 
                                                        choices = c("PC1", "PC2", "PC3", "PC4"),
                                                        selected = c("PC1", "PC2"))
                                   ),
                                   mainPanel(plotOutput("pcaPlot")
                                   )
                                 )
                        ),
   tabPanel("Summary", verbatimTextOutput("pcaSummary")),
   tabPanel("Data", tableOutput("pcaTable"))
                        )
             ),
   tabPanel("CA",
   tabsetPanel(tabPanel("Plot",sidebarLayout(sidebarPanel(checkboxGroupInput("caDims", "Chose 2 column:：", 
                                                        choices = c("Dim1", "Dim2", "Dim3"),
                                                        selected = c("Dim1", "Dim2"))),
   mainPanel(plotOutput("caPlot") ))
                        ),
  tabPanel("Summary", verbatimTextOutput("caSummary")),tabPanel("Data", tableOutput("caTable"))
                      )
             )
             
  )
  
  
  
)


Server <- function(input, output) {
  # iris data -> Plot
  output$irisPlot <- renderPlot({
    req(input$iris_variables)
    if (length(input$iris_variables) < 2) {
      return(NULL)
    }
    
    data(iris)
    X <- input$iris_variables[1]
    Y <- input$iris_variables[2]
    
    ggplot(iris, aes_string(x = X, y = Y, color = "Species")) +
      geom_point() +
      labs(title = paste("Iris Dataset", X, "vs", Y), x = X, y = Y) +
      theme_minimal()
  })
  
  # iris data -> Summary
  output$irisSummary <- renderPrint({
    data(iris)
    summary(iris)
  })
  
  # iris data -> Table
  output$irisTable <- renderTable({
    data(iris)
    iris
  })
  
  
  
  
  
  # pca
  iris.pca <- prcomp(iris[, 1:4], center = TRUE, scale. = TRUE)
  
  # pca -> Plot
  output$pcaPlot <- renderPlot({
    req(input$PCs)
    if (length(input$PCs) < 2) {
      return(NULL)
    }
    
    sele_PC <- as.integer(gsub("PC", "", input$PCs))
    ggbiplot(iris.pca, choices = sele_PC, obs.scale = 1, var.scale = 1,
             groups = iris$Species, ellipse = TRUE, circle = TRUE) +
      scale_color_discrete(name = '') +
      theme_minimal()
  })
  
  # pca -> Summary
  output$pcaSummary <- renderPrint({
    summary(iris.pca)
  })
  
  # pca -> Table
  output$pcaTable <- renderTable({
    Pca_x <- data.frame(iris.pca$x)
    colnames(Pca_x) <- paste("PC", 1:ncol(Pca_x), sep = "")
    Pca_x <- cbind(Pca_x, Species = iris$Species)
    Pca_x
  })
  
  
  
  
  
  # ca
  iris_ca <- CA(iris[, -5])
  
  # ca -> Plot
  output$caPlot <- renderPlot({
    req(input$caDims)
    if (length(input$caDims) < 2) {
      return(NULL)
    }
    
    selected_dims <- as.integer(gsub("D", "", input$caDims))
    fviz_ca_biplot(iris_ca, axes = selected_dims, repel = TRUE, col.row = iris$Species,
                   ggtheme = theme_minimal())
  })
  
  # ca -> Summary
  output$caSummary <- renderPrint({
    summary(iris_ca)
  })
  
  # ca -> Table
  output$caTable <- renderTable({
    ca_scores <- data.frame(iris_ca$row$coord)
    colnames(ca_scores) <- paste("Dim", 1:ncol(ca_scores), sep = "")
    ca_scores <- cbind(ca_scores, Species = iris$Species)
    ca_scores
  })
}
shinyApp(ui = ui, server = Server)




